# Normalizador de runsheets y títulos

**En una frase:** convierte runsheets de propiedad mineral que llegan en formatos
distintos —Excel o PDF, con encabezados diferentes en cada archivo— en dos
tablas normalizadas listas para cargar al software de tierras, más un reporte de
todo lo que quedó dudoso.

| | |
|---|---|
| Pregunta de negocio | ¿Cómo cargar cientos de runsheets de formatos distintos sin transcribirlos a mano ni introducir errores en la cadena de título? |
| Datos | Runsheets de condados de Texas y Luisiana en .xlsx, .xls y PDF, con encabezados no estandarizados |
| Herramientas | Python, pandas, openpyxl, pdfplumber |
| Entregable | Tres scripts de línea de comandos; salida en Excel con formato |
| Volumen de código | 2.900 líneas |

## El problema

Un runsheet es el índice cronológico de los instrumentos que afectan a un
tracto: quién le transfirió qué a quién, cuándo, y en qué libro y página quedó
registrado. Cada condado, cada abstractor y cada cliente lo entrega distinto. La
misma columna puede llamarse `GRANTOR`, `PARTY OF THE FIRST PART` o `FROM`. El
libro y la página pueden venir en dos columnas o combinados como `375-266`,
`104/287`, `330_25` o `Vol 104 Pg 287`. El encabezado real puede estar en la
fila 1 o en la 14, debajo de un título. Y una fila puede estar partida en tres
líneas físicas porque el texto se desbordó.

Normalizar eso a mano es lento y, peor, es donde se introducen los errores que
después rompen la cadena de título.

## Qué hace

**`normalizer.py`** procesa cada runsheet de la carpeta, sea Excel o PDF:

- Resuelve los nombres de columna contra un diccionario de alias (`HEADER_ALIASES`) que cubre las variantes que aparecen en la práctica.
- Busca el encabezado real en las primeras 30 filas, no asume que sea la primera.
- Separa libro y página vengan como vengan, y aísla el prefijo de tipo de libro (`DR`, `OR`) para usarlo como Booktype, que es más confiable que inferirlo del año.
- Rejunta las filas partidas en varias líneas.
- En PDF lee cada tabla de cada página por separado, porque estos runsheets repiten el encabezado en cada página y el número de columnas detectado varía.
- Deduplica el mismo instrumento cuando llega repetido en las hojas «Main» e «Index» del mismo archivo o en runsheets suplementarios que se traslapan.
- Nunca deja un otorgante o beneficiario en blanco: lo marca como dudoso y lo lista en el reporte con el archivo, la hoja y la fila de origen para poder verificarlo contra el documento.

Clasifica la salida en dos archivos: **CD** (Conveyance, Assignment, Lease,
Release) y **NCD** (Deed of Trust, Easement, Agreement, Lien y demás).

**`history_of_title_to_xlsx.py`** resuelve el caso más difícil: una opinión de
título narrativa en PDF, que no es una tabla. Reconstruye la indentación
original a partir de las posiciones de las palabras, y así distingue un ítem
real de una sublista numerada anidada. Detecta condado y estado del propio texto.

**`runsheet_formatter.py`** da el formato final de Excel a las 24 columnas de
salida, con estilos y anchos, para que se pueda entregar tal cual.

## Resultado con los datos de ejemplo

![Antes y después del normalizador](capturas/antes_despues.png)

Arriba, dos de los tres formatos de entrada: uno con `GRANTOR`/`GRANTEE` y
libro y página en columnas separadas, otro con `PARTY OF THE FIRST PART`,
`VOL-PG` combinado y el encabezado en la cuarta fila. Abajo, la salida: un solo
esquema, el tipo de instrumento clasificado, y el libro y la página separados con
su prefijo de tipo de libro aislado.

Los runsheets reales son de clientes y no se publican. En `datos-ejemplo/` hay
un generador que fabrica tres formatos sintéticos con los mismos problemas.
Corriendo el normalizador sobre ellos:

```
File processed successfully: formato_a.xlsx
File processed successfully: formato_b.xlsx
Skipping formato_c.xlsx (no runsheet tables detected)

Done. File generated: Normalized_Runsheet_CD.xlsx (37 records)
Done. File generated: Normalized_Runsheet_NCD.xlsx (14 records)
Report generated: Normalized_Runsheet_MissingFields.txt (1 records flagged)
```

Los dos primeros formatos se normalizaron completos, incluido el que trae tres
filas de título antes del encabezado y el libro-página combinado. La única fila
marcada fue la que tenía el otorgante ilegible, que es exactamente lo que debía
pasar.

## Limitaciones

**`formato_c.xlsx` no se detecta.** La detección de encabezado exige encontrar
`GRANTOR`+`GRANTEE`, uno de los marcadores de `HEADER_ROW_MARKERS`, o
`INSTRUMENT`+`BK`. Un runsheet con encabezados abreviados tipo `INSTR.` / `FROM`
/ `TO` pasa de largo, aunque los alias de columna sí los reconocen. Es la
próxima mejora: bastaría con puntuar la fila candidata por número de alias
reconocidos en lugar de exigir una combinación fija.

Las fechas ambiguas de dos dígitos (`04/12/07`) se interpretan con una heurística
por siglo; un runsheet con fechas anteriores a 1900 puede necesitar revisión
manual. Y el reconocimiento de tablas en PDF depende de que el documento tenga
capa de texto: los escaneados hay que pasarlos primero por el
[proyecto de OCR](../04-ocr-documentos).

## Cómo correrlo

```bash
pip install pandas openpyxl pdfplumber xlrd matplotlib
python datos-ejemplo/generar_ejemplos.py      # crea tres runsheets de ejemplo
cd datos-ejemplo && python ../src/normalizer.py
python capturas/generar_captura.py            # regenera la imagen de arriba
```

`normalizer.py` procesa todo lo que encuentre en el directorio actual, así que
se ejecuta desde la carpeta que contiene los runsheets.

## Estructura

```
01-normalizador-titulos/
├── src/normalizer.py                 normaliza runsheets (Excel y PDF)
├── src/history_of_title_to_xlsx.py   opiniones de título narrativas en PDF
├── src/runsheet_formatter.py         formato final de Excel
├── datos-ejemplo/generar_ejemplos.py tres runsheets sintéticos para probar
└── capturas/generar_captura.py       genera la imagen de antes y después
```
