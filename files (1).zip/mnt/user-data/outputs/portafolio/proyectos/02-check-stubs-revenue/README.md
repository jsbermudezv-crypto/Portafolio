# Extracción de check stubs y consolidación de revenue

**En una frase:** extrae los datos de pago de estados de cuenta de regalías en
PDF —ocho formatos distintos según el operador— y los consolida, junto con
division orders, revenue statements y el maestro de pozos, en un solo log de
3.441 tracts con el nivel de confianza de cada dato marcado.

| | |
|---|---|
| Pregunta de negocio | ¿Qué intereses estamos cobrando en cada tract, y coinciden con lo que dicen los division orders? |
| Datos | 763.000 filas de cinco fuentes: check stubs en PDF de ocho operadores, division orders, revenue statements, maestro de pozos y documentos de ingeniería |
| Herramientas | Python, pdfplumber, openpyxl, difflib |
| Entregable | Excel con seis hojas: log consolidado, resumen de análisis y cuatro hojas de excepciones |
| Volumen de código | 2.500 líneas |

## El problema

Cada operador emite su estado de cuenta con su propio diseño. EnergyLink usa un
prefijo `Property:`; SM Energy y XTO usan el mismo sistema pero sin prefijo y con
códigos numéricos basados en fecha; VTX reporta un «Owner Net» por pozo;
BCE-Mach usa una tabla de Revenue Distribution; Blue Cedar emite un
Supplemental Check Voucher; Comstock manda un ACH Remittance Statement. Atlas y
SOGC tienen su propio formato también.

Extraer eso a mano significa abrir cada PDF, identificar el formato, buscar los
pozos y transcribir importes e intereses. Y después viene lo más difícil:
comprobar que el interés que paga el operador coincide con el que dice el
division order. Sin automatizar, esa comprobación no se hace, o se hace por
muestreo.

## Qué hace

**`check_stub_auto.py`** detecta el formato del PDF y aplica el parser
correspondiente: una función por operador (`parse_energylink`, `parse_vtx`,
`parse_bce_mach`, `parse_blue_cedar`, `parse_comstock`, `parse_atlas`,
`parse_sogc`) más un parser de propiedades común. Extrae pozo, importe, interés
y periodo, y escribe un Excel con formato.

**`project_log_v5.py`** es la consolidación. Cruza los cinco insumos y produce el
log final:

- Empareja pozos entre fuentes con `difflib`, porque los nombres nunca coinciden exactamente entre operador y registro interno.
- **Clasifica cada coincidencia por nivel de confianza** en lugar de tratarlas como iguales: descripción legal completa, descripción legal más entidad, sección y condado, solo condado y entidad, o no encontrado. Ese nivel viaja con el dato hasta el Excel final.
- Cuando una celda nueva queda vacía, cae a la versión anterior del log en lugar de perder el dato.
- Resuelve los decimales de interés por mediana cuando las fuentes discrepan, en vez de quedarse con el primero.

**`read_statements.py`** lee el Excel de la carpeta y muestra en consola las
columnas clave (parte, regalía, NRI, LOR, acres brutos, NMRA) para revisar de un
vistazo.

## Resultados

![Fuentes consolidadas](graficos/fuentes_consolidadas.png)

**763.000 filas de cinco fuentes en un solo log de 3.441 tracts.** El maestro de
pozos aporta 733.805 filas, los division orders 9.656, los revenue statements
8.877 y los documentos de ingeniería 7.176.

![Cobertura de division orders](graficos/cobertura_division_orders.png)

**99,6% de cobertura de division orders**, pero el gráfico muestra lo que
importa: solo el 20% de los tracts coincidió por descripción legal completa. El
55% coincidió por sección y condado, y el 22% únicamente por condado y entidad.
Esa distinción es el aporte real del proyecto: un log que reportara «99,6%
localizado» sin más induciría a confiar en 2.661 emparejamientos de confianza
media o baja.

![Cobertura por estado](graficos/cobertura_por_estado.png)

**Nuevo México quedó como el hueco visible:** 100% de cobertura de division
orders y solo 55% de revenue statements, contra 94% en Texas y Dakota del Norte.
Es el estado donde conviene revisar variantes de nombre de operador antes de
seguir buscando documentos.

**Cifras de cierre del proceso**, todas agregadas y sin identificar tracts,
pozos ni propietarios:

| Métrica | Resultado |
|---|---|
| Tracts consolidados | 3.441 |
| Cobertura de division order | 3.427 (99,6%) |
| Cobertura de revenue statement | 3.072 (89,3%) |
| Entradas de nombre de pozo identificadas | 49.424 |
| Tracts con API14 y API10 resueltos | 3.431 |
| Estados cubiertos | 10 |
| Pagos de regalías reconciliados | ~9,2 millones de dólares |

**Y lo que el proceso dejó accionable**, en hojas separadas con la acción
recomendada: 90 tracts sin division order localizado, 756 que necesitan
confirmar sección-municipio-rango en la descripción legal, y 369 sin revenue
statement encontrado. En lugar de un informe que dice «faltan datos», el
entregable dice cuáles faltan y qué hacer con cada grupo.

La comparación de decimales entre division order y revenue statement quedó
incluida por entidad, que es la que destapa las diferencias a reclamar.

## Limitaciones

Los parsers están acoplados al diseño de cada operador: si EnergyLink cambia su
plantilla, hay que ajustar el parser. La detección de formato es por patrones de
texto, así que un PDF escaneado sin capa de texto no funciona hasta pasarlo por
el [proyecto de OCR](../04-ocr-documentos). El emparejamiento con `difflib` es
una heurística, y por eso el nivel de confianza acompaña a cada dato en lugar de
asumir que el cruce es correcto: los 1.905 tracts de nivel moderado siguen
necesitando verificación humana.

## Cómo correrlo

Los datos son de cliente y no se incluyen. Con tus propios archivos:

```bash
pip install pdfplumber openpyxl tqdm pandas tabulate
export TIKI_DATA_DIR=/ruta/a/los/insumos    # antes estaba fijo a una ruta de Windows
python src/check_stub_auto.py
python src/project_log_v5.py
python graficos/generar_graficos.py         # regenera los gráficos de arriba
```

## Estructura

```
02-check-stubs-revenue/
├── src/check_stub_auto.py       extrae ocho formatos de check stub de PDF a Excel
├── src/project_log_v5.py        consolida cinco fuentes en el log final
├── src/read_statements.py       verificación rápida en consola
└── graficos/                    cobertura y volumen, con cifras agregadas
```
